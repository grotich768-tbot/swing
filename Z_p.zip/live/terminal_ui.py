"""
live/terminal_ui.py — polished Rich terminal dashboard for the live trading bot.

Goals:
- keep the CMD window readable
- show only the most useful live state
- avoid noisy print spam from the trading loop
- work safely even when MT5 drops briefly
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from threading import RLock
from typing import Deque, Dict, Optional

from rich import box
from rich.align import Align
from rich.console import Console, Group, RenderableType
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.layout import Layout

LEVEL_STYLES = {
    "DEBUG": "dim",
    "INFO": "cyan",
    "SUCCESS": "green",
    "WARNING": "yellow",
    "ERROR": "red",
    "CRITICAL": "bold red",
}


@dataclass
class EventItem:
    ts: datetime
    level: str
    message: str


class TerminalUI:
    """Compact live dashboard for command-line monitoring."""

    def __init__(self, settings):
        self.s = settings
        self.console = Console()
        self._lock = RLock()
        self._live: Optional[Live] = None
        self._running = False
        self._started_at = datetime.now(timezone.utc)
        self._snapshot: Dict = {}
        self._events: Deque[EventItem] = deque(
            maxlen=max(6, int(getattr(settings, "terminal_ui_max_events", 8)))
        )
        self._refresh_seconds = max(0.25, float(getattr(settings, "terminal_ui_refresh_seconds", 1.0)))

    def start(self):
        if not getattr(self.s, "terminal_ui_enabled", True):
            return
        with self._lock:
            if self._running:
                return

            # screen=True gives a clean dashboard view rather than interleaving
            # with raw console output.
            self._live = Live(
                self.render(),
                console=self.console,
                refresh_per_second=max(1.0, 1.0 / self._refresh_seconds),
                transient=False,
                screen=True,
            )
            self._live.__enter__()
            self._running = True

    def stop(self):
        with self._lock:
            if self._live is not None:
                try:
                    self._live.__exit__(None, None, None)
                finally:
                    self._live = None
            self._running = False

    def emit(self, level: str, message: str, ts: Optional[datetime] = None):
        if not getattr(self.s, "terminal_ui_enabled", True):
            return
        level = (level or "INFO").upper()
        ts = ts or datetime.now(timezone.utc)
        with self._lock:
            self._events.append(EventItem(ts=ts, level=level, message=str(message)))
            self._refresh_locked()

    def update(self, snapshot: Dict):
        if not getattr(self.s, "terminal_ui_enabled", True):
            return
        with self._lock:
            self._snapshot = dict(snapshot or {})
            self._refresh_locked()

    def _refresh_locked(self):
        if self._running and self._live is not None:
            self._live.update(self.render())

    def _render_header(self) -> Panel:
        snap = self._snapshot
        mode = snap.get("mode", getattr(self.s, "trading_mode", "DEMO"))
        conn = snap.get("connection", "DISCONNECTED")
        reason = snap.get("reason", "")
        uptime = snap.get("uptime", self._format_uptime())
        timestamp = snap.get("timestamp", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

        title = Text(" Z+ LIVE TRADING TERMINAL ", style="bold white on dark_blue")
        subtitle = Text()
        subtitle.append(f" Mode: {mode}  ", style="white")
        subtitle.append(f"MT5: {conn}  ", style="green" if conn == "CONNECTED" else "red")
        subtitle.append(f"Uptime: {uptime}  ", style="white")
        subtitle.append(f"{timestamp}", style="dim")

        if snap.get("circuit_breaker_active"):
            status = Text(" CIRCUIT BREAKER ACTIVE ", style="bold white on red")
        elif snap.get("daily_halt"):
            status = Text(" DAILY LOSS HALT ACTIVE ", style="bold white on dark_red")
        elif snap.get("mt5_down"):
            status = Text(" MT5 RECONNECTING ", style="bold black on yellow")
        else:
            status = Text(" READY ", style="bold black on green")

        if reason:
            subtitle.append(f"  • {reason}", style="magenta")

        body = Group(title, subtitle, Align.left(status))
        return Panel(body, box=box.ROUNDED, padding=(1, 2), border_style="cyan")

    def _metric_card(self, label: str, value: str, style: str = "white") -> Panel:
        return Panel(
            Align.center(Text(value, style=f"bold {style}"), vertical="middle"),
            title=label,
            box=box.ROUNDED,
            border_style=style,
            padding=(0, 1),
            height=5,
        )

    def _render_metrics(self) -> Panel:
        snap = self._snapshot
        balance = snap.get("balance")
        equity = snap.get("equity")
        drawdown = snap.get("drawdown_pct")
        daily_loss = snap.get("daily_loss_usd")
        open_trades = snap.get("open_trades")
        exposure = snap.get("exposure_lots")

        grid = Table.grid(expand=True)
        for _ in range(3):
            grid.add_column(ratio=1)

        row1 = [
            self._metric_card("Balance", self._fmt_money(balance), "bright_blue"),
            self._metric_card("Equity", self._fmt_money(equity), "green"),
            self._metric_card("Drawdown", self._fmt_pct(drawdown), "yellow"),
        ]
        row2 = [
            self._metric_card("Daily Loss", self._fmt_money(daily_loss), "red"),
            self._metric_card("Open Trades", str(open_trades if open_trades is not None else "—"), "magenta"),
            self._metric_card("Exposure", f"{exposure:.2f} lots" if exposure is not None else "—", "cyan"),
        ]

        grid.add_row(*row1)
        grid.add_row(*row2)
        return Panel(grid, title="Account Overview", border_style="bright_blue", box=box.ROUNDED)

    def _render_positions(self) -> Panel:
        positions = self._snapshot.get("positions", []) or []
        table = Table(
            box=box.SIMPLE_HEAVY,
            expand=True,
            show_lines=False,
            pad_edge=False,
        )
        table.add_column("Symbol", style="cyan", no_wrap=True)
        table.add_column("Side", no_wrap=True)
        table.add_column("Lots", justify="right")
        table.add_column("PnL", justify="right")
        table.add_column("Ticket", justify="right")

        if not positions:
            table.add_row("—", "—", "—", "—", "—")
        else:
            for pos in positions:
                side = pos.get("side_text", "—")
                side_style = "green" if pos.get("side", 0) == 1 else "red"
                pnl = pos.get("profit")
                pnl_text = self._fmt_money(pnl)
                pnl_style = "green" if isinstance(pnl, (int, float)) and pnl >= 0 else "red"
                table.add_row(
                    str(pos.get("symbol", "—")),
                    Text(side, style=side_style),
                    f"{float(pos.get('lots', 0.0)):.2f}",
                    Text(pnl_text, style=pnl_style),
                    str(pos.get("ticket", "—")),
                )

        return Panel(table, title="Open Positions", border_style="green", box=box.ROUNDED)

    def _render_system(self) -> Panel:
        snap = self._snapshot
        table = Table.grid(expand=True)
        table.add_column(justify="left")
        table.add_column(justify="right")

        table.add_row("Risk engine", "ACTIVE" if snap.get("risk_ready", True) else "—")
        table.add_row("Daily halt", "YES" if snap.get("daily_halt") else "NO")
        table.add_row("CB active", "YES" if snap.get("circuit_breaker_active") else "NO")
        table.add_row("Reconnects", str(snap.get("reconnects", 0)))
        table.add_row("Models", f"{snap.get('models_loaded', 0)}/{snap.get('models_expected', 0)}")
        table.add_row("Symbols", ", ".join(snap.get("symbols", [])) or "—")

        last_error = snap.get("last_connect_error")
        body = Group(table, Text(f"Last error: {last_error}" if last_error else "", style="dim"))
        return Panel(body, title="System Status", border_style="magenta", box=box.ROUNDED)

    def _render_events(self) -> Panel:
        lines = []
        for item in list(self._events)[-self._events.maxlen :]:
            ts = item.ts.astimezone(timezone.utc).strftime("%H:%M:%S")
            style = LEVEL_STYLES.get(item.level, "white")
            lines.append(Text(f"[{ts}] {item.level:<8} {item.message}", style=style))

        if not lines:
            lines.append(Text("No events yet.", style="dim"))

        return Panel(
            Group(*lines),
            title="Recent Events",
            border_style="yellow",
            box=box.ROUNDED,
            padding=(1, 2),
        )

    def render(self) -> RenderableType:
        layout = Layout()
        layout.split_column(
            Layout(self._render_header(), size=6),
            Layout(name="body", ratio=2),
            Layout(self._render_events(), size=10),
        )
        layout["body"].split_column(
            Layout(self._render_metrics(), size=12),
            Layout(name="lower", ratio=2),
        )
        layout["body"]["lower"].split_row(
            Layout(self._render_positions(), ratio=2),
            Layout(self._render_system(), ratio=1),
        )
        return layout

    def _fmt_money(self, value) -> str:
        if value is None:
            return "—"
        try:
            return f"${float(value):,.2f}"
        except Exception:
            return str(value)

    def _fmt_pct(self, value) -> str:
        if value is None:
            return "—"
        try:
            return f"{float(value):.2%}"
        except Exception:
            return str(value)

    def _format_uptime(self) -> str:
        delta = datetime.now(timezone.utc) - self._started_at
        total = int(delta.total_seconds())
        hours, rem = divmod(total, 3600)
        mins, secs = divmod(rem, 60)
        return f"{hours:02d}:{mins:02d}:{secs:02d}"
