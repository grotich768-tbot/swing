"""
env/trading_env.py  —  Always-In Gymnasium Trading Environment
──────────────────────────────────────────────────────────────────────────────
One environment instance per symbol.

Key design choices
──────────────────
• Always-in: position is always +1 (long) or -1 (short). Never flat.
• Action space: Discrete(2)  →  0 = HOLD,  1 = FLIP
• Observation: normalised feature vector (lookback × n_features features
               + position info + PnL / drawdown context)
• Reward:  risk-adjusted PnL per step − transaction cost − drawdown penalty
           − flip churn penalty
"""

import sys
from pathlib import Path
from typing import Optional

import numpy as np
import gymnasium as gym
from gymnasium import spaces

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import (
    SPREAD_PIPS, PIP_VALUE, FLIP_PENALTY,
    DRAWDOWN_PENALTY_SCALE, INITIAL_BALANCE,
    MAX_EPISODE_STEPS, LOOKBACK_STEPS, COMMISSION_PIPS,
    N_REGIMES,
)


class AlwaysInEnv(gym.Env):
    """
    Always-In trading environment for a single symbol.

    Parameters
    ----------
    features_df : pd.DataFrame
        Normalised feature matrix (output of FeatureEngineer.transform).
        Must contain columns: _close, _atr and normalised feature cols.
    symbol      : str
        Symbol name (used to look up spread / pip value).
    regime_proba : np.ndarray | None
        (n_bars, N_REGIMES) regime probability array from RegimeClassifier.
        If provided, prepended to the observation vector.
    direction_proba : np.ndarray | None
        (n_bars,) directional probability from LSTMDirectionModel.
        If provided, appended to the observation vector.
    mode        : 'train' | 'test'
        Training mode randomly samples episode start; test mode is sequential.
    verbose     : bool
    """

    metadata = {"render_modes": ["human"]}

    def __init__(
        self,
        features_df,
        symbol:            str,
        regime_proba:      Optional[np.ndarray] = None,
        direction_proba:   Optional[np.ndarray] = None,
        mode:              str  = "train",
        verbose:           bool = False,
    ):
        super().__init__()
        self.symbol          = symbol
        self.mode            = mode
        self.verbose         = verbose
        self.spread_pips     = SPREAD_PIPS.get(symbol, 1.0)
        self.pip_value       = PIP_VALUE.get(symbol, 0.0001)
        self.commission_pips = COMMISSION_PIPS

        # ── Data ──────────────────────────────────────────────────────────────
        self._feature_cols = [
            c for c in features_df.columns
            if not c.startswith("_") and not c.startswith("target")
        ]
        self._features   = features_df[self._feature_cols].values.astype(np.float32)
        self._close      = features_df["_close"].values.astype(np.float32)
        self._atr        = features_df["_atr"].values.astype(np.float32)
        self._n_bars     = len(self._features)
        self._n_features = len(self._feature_cols)

        # Optional ML model outputs
        self._regime_proba    = regime_proba     # (n_bars, N_REGIMES) or None
        self._direction_proba = direction_proba  # (n_bars,)           or None

        # ── Observation space ─────────────────────────────────────────────────
        obs_size = self._compute_obs_size()
        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf,
            shape=(obs_size,), dtype=np.float32,
        )

        # ── Action space ──────────────────────────────────────────────────────
        # 0 = HOLD,  1 = FLIP
        self.action_space = spaces.Discrete(2)

        # ── State (set in reset) ──────────────────────────────────────────────
        self._step_idx       = 0
        self._episode_start  = 0
        self._position       = 1       # +1 long | -1 short (start long)
        self._steps_held     = 0
        self._entry_price    = 0.0
        self._balance        = INITIAL_BALANCE
        self._peak_balance   = INITIAL_BALANCE
        self._total_pnl      = 0.0
        self._n_flips        = 0
        self._episode_pnls   = []      # step-level PnL for Sharpe calc

    # ── Gym API ───────────────────────────────────────────────────────────────
    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[dict] = None,
    ):
        super().reset(seed=seed)

        min_start = LOOKBACK_STEPS
        max_start = self._n_bars - MAX_EPISODE_STEPS - 1

        if self.mode == "train":
            self._episode_start = int(
                self.np_random.integers(min_start, max(min_start + 1, max_start))
            )
        else:
            self._episode_start = min_start

        self._step_idx     = self._episode_start
        self._position     = 1
        self._steps_held   = 0
        self._entry_price  = self._close[self._step_idx]
        self._balance      = INITIAL_BALANCE
        self._peak_balance = INITIAL_BALANCE
        self._total_pnl    = 0.0
        self._n_flips      = 0
        self._episode_pnls = []

        return self._get_obs(), {}

    def step(self, action: int):
        assert self.action_space.contains(action), f"Invalid action: {action}"

        prev_price = self._close[self._step_idx]
        self._step_idx += 1

        # In test mode run the full date range.
        # In train mode cap at MAX_EPISODE_STEPS so episodes are manageable.
        if self.mode == "test":
            done = self._step_idx >= self._n_bars - 1
        else:
            done = self._step_idx >= min(
                self._episode_start + MAX_EPISODE_STEPS,
                self._n_bars - 1
            )
        truncated = False

        curr_price = self._close[self._step_idx]
        atr        = self._atr[self._step_idx]

        # ── Execute action ────────────────────────────────────────────────────
        flipped        = False
        transaction_cost = 0.0

        if action == 1:   # FLIP
            flipped            = True
            self._position    *= -1
            self._entry_price  = curr_price
            self._steps_held   = 0
            self._n_flips     += 1
            # Cost: spread + commission (in price units)
            spread_price    = self.spread_pips * self.pip_value
            comm_price      = self.commission_pips * self.pip_value
            transaction_cost = spread_price + comm_price
        else:
            self._steps_held += 1

        # ── PnL calculation ───────────────────────────────────────────────────
        price_change = curr_price - prev_price
        step_pnl     = self._position * price_change - transaction_cost

        # Normalise PnL by ATR so reward is scale-invariant across symbols
        atr_safe   = max(atr, 1e-8)
        step_pnl_n = step_pnl / atr_safe

        self._total_pnl    += step_pnl
        self._balance      += step_pnl
        self._peak_balance  = max(self._peak_balance, self._balance)
        self._episode_pnls.append(step_pnl_n)

        # ── Reward ────────────────────────────────────────────────────────────
        reward = step_pnl_n

        # Flip churn penalty
        if flipped:
            reward -= FLIP_PENALTY

        # Drawdown penalty
        drawdown = (self._peak_balance - self._balance) / (self._peak_balance + 1e-8)
        if drawdown > 0.02:
            reward -= DRAWDOWN_PENALTY_SCALE * drawdown

        # Rolling Sharpe bonus (computed every 20 steps)
        if len(self._episode_pnls) >= 20:
            recent = np.array(self._episode_pnls[-20:])
            sharpe = recent.mean() / (recent.std() + 1e-8) * np.sqrt(252)
            reward += 0.1 * np.clip(sharpe, -2, 2)

        obs  = self._get_obs()
        info = {
            "step_pnl":   step_pnl,
            "total_pnl":  self._total_pnl,
            "balance":    self._balance,
            "drawdown":   drawdown,
            "n_flips":    self._n_flips,
            "position":   self._position,
            "flipped":    flipped,
        }

        if self.verbose and flipped:
            print(
                f"[{self.symbol}] step={self._step_idx}  "
                f"FLIP → {'LONG' if self._position == 1 else 'SHORT'}  "
                f"pnl={self._total_pnl:.4f}"
            )

        return obs, float(reward), done, truncated, info

    def render(self):
        print(
            f"[{self.symbol}]  idx={self._step_idx}  "
            f"pos={'LONG' if self._position==1 else 'SHORT'}  "
            f"bal={self._balance:.2f}  pnl={self._total_pnl:.4f}  "
            f"flips={self._n_flips}"
        )

    # ── Observation builder ───────────────────────────────────────────────────
    def _get_obs(self) -> np.ndarray:
        idx = self._step_idx

        # 1. Lookback feature rows (LOOKBACK_STEPS × n_features, flattened)
        start = max(0, idx - LOOKBACK_STEPS + 1)
        rows  = self._features[start: idx + 1]
        if len(rows) < LOOKBACK_STEPS:
            pad  = np.zeros((LOOKBACK_STEPS - len(rows), self._n_features), dtype=np.float32)
            rows = np.vstack([pad, rows])
        feat_flat = rows.flatten()

        # 2. Position state
        atr_safe     = max(float(self._atr[idx]), 1e-8)
        pos_vec = np.array([
            float(self._position),                                    # +1 or -1
            float(self._steps_held) / 100.0,                          # normalised
            (self._balance - INITIAL_BALANCE) / INITIAL_BALANCE,      # return
            (self._peak_balance - self._balance) / atr_safe,          # drawdown / ATR
            float(self._n_flips) / 100.0,                             # normalised flips
        ], dtype=np.float32)

        parts = [feat_flat, pos_vec]

        # 3. Regime probabilities (if available)
        if self._regime_proba is not None:
            parts.append(self._regime_proba[idx].astype(np.float32))

        # 4. Direction probability (if available)
        if self._direction_proba is not None:
            dir_val = float(self._direction_proba[idx])
            parts.append(np.array([dir_val], dtype=np.float32))

        obs = np.concatenate(parts)
        obs = np.clip(obs, -10, 10)   # safety clip
        return obs

    def _compute_obs_size(self) -> int:
        base = LOOKBACK_STEPS * self._n_features + 5
        if self._regime_proba    is not None: base += N_REGIMES
        if self._direction_proba is not None: base += 1
        return base

    # ── Properties ────────────────────────────────────────────────────────────
    @property
    def n_feature_cols(self) -> int:
        return self._n_features

    def episode_summary(self) -> dict:
        pnls = np.array(self._episode_pnls) if self._episode_pnls else np.array([0.0])
        sharpe = (pnls.mean() / (pnls.std() + 1e-8)) * np.sqrt(252 * 24)
        return {
            "symbol":     self.symbol,
            "total_pnl":  self._total_pnl,
            "balance":    self._balance,
            "n_flips":    self._n_flips,
            "n_steps":    self._step_idx - self._episode_start,
            "sharpe":     sharpe,
            "drawdown":   (self._peak_balance - self._balance) / (self._peak_balance + 1e-8),
        }
